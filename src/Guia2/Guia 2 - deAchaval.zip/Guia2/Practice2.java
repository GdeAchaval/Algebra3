package Guia2;

/**
 * Created by GonzaOK on 21/3/17.
 */
public interface Practice2{

    long exercise8(int m, int n);

    long exercise9(int m, int n, int r, int s);

    long exercise10(int n);

    // Implement sumation
    double exercise11Sumation(int n, int x);

    // Implement equivalent formula
    double exercise11Formula(int n, int x);

}
